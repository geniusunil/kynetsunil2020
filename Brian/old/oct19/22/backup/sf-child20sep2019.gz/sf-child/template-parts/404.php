<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
?>
<main id="main" class="site-main" role="main">

	<header class="page-header">
		<h1 class="entry-title"><?php _e( 'The page can&rsquo;t be found.', 'elementor-hello-theme' ); ?></h1>
	</header>

	<div class="page-content">
		<p><?php _e( 'It looks like nothing was found at this location.', 'elementor-hello-theme' ); ?></p>
	</div>

</main>
