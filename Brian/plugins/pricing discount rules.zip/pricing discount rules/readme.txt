=== Pricing Discount Rules ===
Contributors: lucasstark, OptimizeForm
Tags: woocommerce, price
Requires at least: 3.0
Tested up to: 5.0.2

Pricing Discount Rules

== Installation ==

1. Upload the folder 'woocommerce-pricing' to the '/wp-content/plugins/' directory

2. Activate 'Pricing Discount Rules' through the 'Plugins' menu in WordPress

== Usage ==

1. Edit a product and look for the 'Pricing Discount Rules' tab. 

2. Configure the Pricing Discount Rules options for your product.  Enter numerical values in the From and To fields.  To allow an unlimited number, use the * symbol.
