<?php

/*
 * Plugin Name: Pricing Discount Rules
 * Plugin URI: https://optimizeform.com/
 * Description: Pricing Discount Rules lets you configure Pricing Discount Rules rules for products, categories and members.
 * Version: 1.2
 * Author: OptimizeForm
 * Author URI: https://optimizeform.com/
 * Requires at least: 3.3
 * Tested up to: 5.4.0
 * Text Domain: pricing-discount-rules
 * Domain Path: /i18n/languages/
 * Copyright: © 2020 OptimizeForm.
 * License: GNU General Public License v3.0
 * License URI: http://www.gnu.org/licenses/gpl-3.0.html
 * WC requires at least: 3.0.0
 * WC tested up to: 4.0.2
 */


/**
 * Required functions
 */
if ( !function_exists( 'woothemes_queue_update' ) ) {
	require_once( 'woo-includes/woo-functions.php' );
}


if ( is_woocommerce_active() ) {

	/**
	 * Boot up Pricing Discount Rules
	 */
	WC_Dynamic_Pricing::init();
}

class WC_Dynamic_Pricing {

	/**
	 * @var WC_Dynamic_Pricing
	 */
	private static $instance;

	public static function init() {
		if ( self::$instance == null ) {
			self::$instance = new WC_Dynamic_Pricing();
		}
	}

	/**
	 * @return WC_Dynamic_Pricing The instance of the plugin.
	 */
	public static function instance() {
		if ( self::$instance == null ) {
			self::init();
		}

		return self::$instance;
	}

	private $cached_adjustments = array();

	public $modules = array();

	public $db_version = '2.1';

	public function __construct() {

		add_action( 'init', array( $this, 'load_plugin_textdomain' ) );


		if ( is_admin() ) {
			require 'admin/admin-init.php';

			//Include and boot up the installer.
			include 'classes/class-wc-dynamic-pricing-installer.php';
			WC_Dynamic_Pricing_Installer::init();

		}

		//Include additional integrations
		if ( wc_dynamic_pricing_is_groups_active() ) {
			include 'integrations/groups/groups.php';
		}

		if ( wc_dynamic_pricing_is_memberships_active() ) {
			include 'integrations/memberships/memberships.php';
		}


		//Paypal express
		include 'integrations/paypal-express.php';
		include 'integrations/woocommerce-product-bundles.php';
		include 'classes/class-wc-dynamic-pricing-compatibility.php';

		$rest_prefix         = trailingslashit( rest_get_url_prefix() );
		$is_rest_api_request = ( false !== strpos( $_SERVER['REQUEST_URI'], $rest_prefix ) ); // phpcs:disable WordPress.Security.ValidatedSanitizedInput.MissingUnslash, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized


		if ( ( !is_admin() || defined( 'DOING_AJAX' ) ) && !defined( 'DOING_CRON' ) && !$is_rest_api_request ) {
			$this->load_front_end();
		} elseif ( $is_rest_api_request ) {
			$this->load_rest_api_front_end();
		}

		if ( isset( $_POST['createaccount'] ) ) {
			add_filter( 'woocommerce_dynamic_pricing_is_rule_set_valid_for_user', array(
				$this,
				'new_account_overrides'
			), 10, 2 );
		}

		add_filter( 'woocommerce_dynamic_pricing_get_rule_amount', array( $this, 'convert_decimals' ), 99, 4 );
	}

	/**
	 * Localisation
	 */
	public function load_plugin_textdomain() {
		$locale = apply_filters( 'plugin_locale', get_locale(), 'pricing-discount-rules' );
		$dir    = trailingslashit( WP_LANG_DIR );

		load_textdomain( 'pricing-discount-rules', $dir . 'pricing-discount-rules/pricing-discount-rules-' . $locale . '.mo' );
		load_plugin_textdomain( 'pricing-discount-rules', false, dirname( plugin_basename( __FILE__ ) ) . '/i18n/languages/' );
	}

	public function load_rest_api_front_end() {
		//Include helper classes
		include 'classes/class-wc-dynamic-pricing-context.php';
		include 'classes/class-wc-dynamic-pricing-counter.php';
		include 'classes/class-wc-dynamic-pricing-tracker.php';

		//Include the collectors.
		include 'classes/collectors/class-wc-dynamic-pricing-collector.php';
		include 'classes/collectors/class-wc-dynamic-pricing-collector-category.php';
		include 'classes/collectors/class-wc-dynamic-pricing-collector-category-inclusive.php';

		//Include the adjustment sets.
		include 'classes/class-wc-dynamic-pricing-adjustment-set.php';
		include 'classes/class-wc-dynamic-pricing-adjustment-set-category.php';
		include 'classes/class-wc-dynamic-pricing-adjustment-set-product.php';
		include 'classes/class-wc-dynamic-pricing-adjustment-set-totals.php';
		include 'classes/class-wc-dynamic-pricing-adjustment-set-taxonomy.php';


		//The base pricing module.
		include 'classes/modules/class-wc-dynamic-pricing-module-base.php';

		//Include the advanced pricing modules.
		include 'classes/modules/class-wc-dynamic-pricing-advanced-base.php';
		include 'classes/modules/class-wc-dynamic-pricing-advanced-product.php';
		include 'classes/modules/class-wc-dynamic-pricing-advanced-category.php';
		include 'classes/modules/class-wc-dynamic-pricing-advanced-totals.php';
		include 'classes/modules/class-wc-dynamic-pricing-advanced-taxonomy.php';

		//Include the simple pricing modules.
		include 'classes/modules/class-wc-dynamic-pricing-simple-base.php';
		include 'classes/modules/class-wc-dynamic-pricing-simple-product.php';
		include 'classes/modules/class-wc-dynamic-pricing-simple-category.php';
		include 'classes/modules/class-wc-dynamic-pricing-simple-membership.php';
		include 'classes/modules/class-wc-dynamic-pricing-simple-taxonomy.php';



		//Boot up the instances of the pricing modules
		$modules['advanced_product']  = WC_Dynamic_Pricing_Advanced_Product::instance();
		$modules['advanced_category'] = WC_Dynamic_Pricing_Advanced_Category::instance();

		$modules['simple_product']    = WC_Dynamic_Pricing_Simple_Product::instance();
		$modules['simple_category']   = WC_Dynamic_Pricing_Simple_Category::instance();
		$modules['simple_membership'] = WC_Dynamic_Pricing_Simple_Membership::instance();

		if ( wc_dynamic_pricing_is_groups_active() ) {
			include 'integrations/groups/class-wc-dynamic-pricing-simple-group.php';
			$modules['simple_group'] = WC_Dynamic_Pricing_Simple_Group::instance();
		}

		if ( wc_dynamic_pricing_is_memberships_active() ) {
			include 'integrations/woocommerce-memberships.php';
			WC_Dynamic_Pricing_Memberships_Integration::register();
		}


		$this->modules = apply_filters( 'wc_dynamic_pricing_load_modules', $modules );

		/* Boot up required classes */
		WC_Dynamic_Pricing_Context::register();

		add_action( 'plugins_loaded', array( $this, 'on_plugins_loaded' ), 0 );
		add_filter( 'woocommerce_product_is_on_sale', array( $this, 'on_get_product_is_on_sale' ), 10, 2 );
		add_filter( 'woocommerce_composite_get_price', array( $this, 'on_get_composite_price' ), 10, 2 );
		add_filter( 'woocommerce_composite_get_base_price', array( $this, 'on_get_composite_base_price' ), 10, 2 );
		add_filter( 'woocommerce_coupon_is_valid', array( $this, 'check_cart_coupon_is_valid' ), 99, 2 );
		add_filter( 'woocommerce_coupon_is_valid_for_product', array( $this, 'check_coupon_is_valid' ), 99, 4 );
		add_filter( 'woocommerce_get_variation_prices_hash', array(
			$this,
			'on_woocommerce_get_variation_prices_hash'
		), 99, 1 );
	}

	public function load_front_end() {
		//Include helper classes
		include 'classes/class-wc-dynamic-pricing-context.php';
		include 'classes/class-wc-dynamic-pricing-counter.php';
		include 'classes/class-wc-dynamic-pricing-tracker.php';
		include 'classes/class-wc-dynamic-pricing-cart-query.php';

		//Include the collectors.
		include 'classes/collectors/class-wc-dynamic-pricing-collector.php';
		include 'classes/collectors/class-wc-dynamic-pricing-collector-category.php';
		include 'classes/collectors/class-wc-dynamic-pricing-collector-category-inclusive.php';

		//Include the adjustment sets.
		include 'classes/class-wc-dynamic-pricing-adjustment-set.php';
		include 'classes/class-wc-dynamic-pricing-adjustment-set-category.php';
		include 'classes/class-wc-dynamic-pricing-adjustment-set-product.php';
		include 'classes/class-wc-dynamic-pricing-adjustment-set-totals.php';
		include 'classes/class-wc-dynamic-pricing-adjustment-set-taxonomy.php';


		//The base pricing module.
		include 'classes/modules/class-wc-dynamic-pricing-module-base.php';

		//Include the advanced pricing modules.
		include 'classes/modules/class-wc-dynamic-pricing-advanced-base.php';
		include 'classes/modules/class-wc-dynamic-pricing-advanced-product.php';
		include 'classes/modules/class-wc-dynamic-pricing-advanced-category.php';
		include 'classes/modules/class-wc-dynamic-pricing-advanced-totals.php';
		include 'classes/modules/class-wc-dynamic-pricing-advanced-taxonomy.php';

		//Include the simple pricing modules.
		include 'classes/modules/class-wc-dynamic-pricing-simple-base.php';
		include 'classes/modules/class-wc-dynamic-pricing-simple-product.php';
		include 'classes/modules/class-wc-dynamic-pricing-simple-category.php';
		include 'classes/modules/class-wc-dynamic-pricing-simple-membership.php';
		include 'classes/modules/class-wc-dynamic-pricing-simple-taxonomy.php';


		//Include the UX module - This controls the display of discounts on cart items and products.
		include 'classes/class-wc-dynamic-pricing-frontend-ux.php';


		//Boot up the instances of the pricing modules
		$modules['advanced_product']  = WC_Dynamic_Pricing_Advanced_Product::instance();
		$modules['advanced_category'] = WC_Dynamic_Pricing_Advanced_Category::instance();

		$modules['simple_product']    = WC_Dynamic_Pricing_Simple_Product::instance();
		$modules['simple_category']   = WC_Dynamic_Pricing_Simple_Category::instance();
		$modules['simple_membership'] = WC_Dynamic_Pricing_Simple_Membership::instance();

		if ( wc_dynamic_pricing_is_groups_active() ) {
			include 'integrations/groups/class-wc-dynamic-pricing-simple-group.php';
			$modules['simple_group'] = WC_Dynamic_Pricing_Simple_Group::instance();
		}

		if ( wc_dynamic_pricing_is_memberships_active() ) {
			include 'integrations/woocommerce-memberships.php';
			WC_Dynamic_Pricing_Memberships_Integration::register();
		}

		$modules['advanced_totals'] = WC_Dynamic_Pricing_Advanced_Totals::instance();

		$this->modules = apply_filters( 'wc_dynamic_pricing_load_modules', $modules );


		/* Boot up required classes */
		WC_Dynamic_Pricing_Context::register();

		//Initialize the Pricing Discount Rules counter.  Records various counts when items are restored from session.
		WC_Dynamic_Pricing_Counter::register();

		//Initialize the FrontEnd UX modifications
		WC_Dynamic_Pricing_FrontEnd_UX::init();

		add_action( 'wp_loaded', array( $this, 'on_wp_loaded' ), 0 );

		add_action( 'plugins_loaded', array( $this, 'on_plugins_loaded' ), 0 );


		add_filter( 'woocommerce_product_is_on_sale', array( $this, 'on_get_product_is_on_sale' ), 10, 2 );


		add_filter( 'woocommerce_composite_get_price', array( $this, 'on_get_composite_price' ), 10, 2 );
		add_filter( 'woocommerce_composite_get_base_price', array( $this, 'on_get_composite_base_price' ), 10, 2 );

		add_filter( 'woocommerce_coupon_is_valid', array( $this, 'check_cart_coupon_is_valid' ), 99, 2 );
		add_filter( 'woocommerce_coupon_is_valid_for_product', array( $this, 'check_coupon_is_valid' ), 99, 4 );

		add_filter( 'woocommerce_get_variation_prices_hash', array(
			$this,
			'on_woocommerce_get_variation_prices_hash'
		), 99, 1 );

		add_action( 'woocommerce_cart_loaded_from_session', array( $this, 'on_cart_loaded_from_session' ), 98, 1 );

		//Add the actions Pricing Discount Rules uses to trigger price adjustments
		add_action( 'woocommerce_before_calculate_totals', array( $this, 'on_calculate_totals' ), 98, 1 );
	}


	public function on_woocommerce_get_variation_prices_hash( $price_hash ) {

		//Get a key based on role, since all rules use roles.
		$result     = is_array( $price_hash ) ? $price_hash : array( $price_hash );
		$session_id = null;

		$roles = array();
		if ( is_user_logged_in() ) {
			$user = new WP_User( get_current_user_id() );
			if ( !empty( $user->roles ) && is_array( $user->roles ) ) {
				foreach ( $user->roles as $role ) {
					$roles[ $role ] = $role;
				}
			}
		}

		if ( !empty( $roles ) ) {
			$session_id = implode( '', $roles );
		} else {
			$session_id = 'norole';
		}

		$result[] = $session_id;

		return $result;

	}


	/**
	 * Add the price filters back in after mini-cart is done.
	 *
	 * @since 2.10.2
	 */
	public function add_price_filters() {

		if ( WC_Dynamic_Pricing_Compatibility::is_wc_version_gte_2_7() ) {
			//Filters the regular variation price

			add_filter( 'woocommerce_product_variation_get_price', array(
				$this,
				'on_get_product_variation_price'
			), 10, 2 );

			//Filters the regular product get price.
			add_filter( 'woocommerce_product_get_price', array( $this, 'on_get_price' ), 10, 2 );
		} else {
			add_filter( 'woocommerce_get_price', array( $this, 'on_get_price' ), 10, 2 );
		}

	}

	/**
	 * Remove the price filter when mini-cart is triggered.
	 *
	 * @since 2.10.2
	 */
	public function remove_price_filters() {
		if ( WC_Dynamic_Pricing_Compatibility::is_wc_version_gte_2_7() ) {
			//Filters the regular variation price
			remove_filter( 'woocommerce_product_variation_get_price', array(
				$this,
				'on_get_product_variation_price'
			), 10, 2 );


			//Filters the regular product get price.
			remove_filter( 'woocommerce_product_get_price', array( $this, 'on_get_price' ), 10, 2 );
		} else {
			remove_filter( 'woocommerce_get_price', array( $this, 'on_get_price' ), 10, 2 );
		}

	}


	public function on_wp_loaded() {
		// Force calculation of totals so that they are updated in mini-cart
		if ( WC_Dynamic_Pricing_Compatibility::is_wc_version( '3.2.5' ) || WC_Dynamic_Pricing_Compatibility::is_wc_version( '3.2.4' ) || WC_Dynamic_Pricing_Compatibility::is_wc_version( '3.2.3' ) ) {
			if ( defined( 'WC_DOING_AJAX' ) && WC_DOING_AJAX && !empty( $_REQUEST['wc-ajax'] ) && ( $_REQUEST['wc-ajax'] === 'get_refreshed_fragments' || $_REQUEST['wc-ajax'] === 'add_to_cart' || $_REQUEST['wc-ajax'] == 'remove_from_cart' ) ) {
				WC()->session->set( 'cart_totals', null );
			}
		}
	}


	public function on_plugins_loaded() {

		require_once 'classes/class-wc-dynamic-pricing-compatibility-functions.php';
		add_filter( 'woocommerce_variation_prices_price', array( $this, 'on_get_variation_prices_price' ), 10, 3 );

		if ( WC_Dynamic_Pricing_Compatibility::is_wc_version_gte_2_7() ) {
			$this->add_price_filters();
		} else {
			add_filter( 'woocommerce_get_variation_price', array( $this, 'on_get_variation_price' ), 10, 4 );
			add_filter( 'woocommerce_get_price', array( $this, 'on_get_price' ), 10, 2 );
		}


		$additional_taxonomies = apply_filters( 'wc_dynamic_pricing_get_discount_taxonomies', array() );

		if ( $additional_taxonomies ) {
			foreach ( $additional_taxonomies as $additional_taxonomy ) {

				$simple_taxonomy_module = apply_filters( 'wc_dynamic_pricing_get_taxonomy_simple_class', 'WC_Dynamic_Pricing_Simple_Taxonomy', $additional_taxonomy );
				if ( $simple_taxonomy_module && class_exists( $simple_taxonomy_module ) ) {
					$this->modules[ 'simple_taxonomy_' . $additional_taxonomy ] = $simple_taxonomy_module::instance( $additional_taxonomy );
				}

				$advanced_taxonomy_module = apply_filters( 'wc_dynamic_pricing_get_taxonomy_advanced_class', 'WC_Dynamic_Pricing_Advanced_Taxonomy', $additional_taxonomy );
				if ( $advanced_taxonomy_module && class_exists( $advanced_taxonomy_module ) ) {
					$this->modules[ 'advanced_taxonomy_' . $additional_taxonomy ] = $advanced_taxonomy_module::instance( $additional_taxonomy );
				}

			}
		}
	}

	public function check_coupon_is_valid( $valid, $product, $coupon, $values ) {

		if ( WC_Dynamic_Pricing_Compatibility::is_wc_version_gte_2_7() ) {

			if ( !apply_filters( 'wc_dynamic_pricing_check_coupons', true ) ) {
				return $valid;
			}

			if ( $coupon->get_exclude_sale_items() && isset( $values['discounts'] ) && isset( $values['discounts']['applied_discounts'] ) && !empty( $values['discounts']['applied_discounts'] ) ) {
				$valid = false;
			}
		} else {
			if ( $coupon->exclude_sale_items() && isset( $values['discounts']['applied_discounts'] ) && !empty( $values['discounts']['applied_discounts'] ) ) {
				$valid = false;
			}
		}


		return $valid;
	}

	/**
	 * @param bool $valid
	 * @param WC_Coupon $coupon
	 *
	 * @return bool
	 */
	public function check_cart_coupon_is_valid( $valid, $coupon ) {
		if ( WC_Dynamic_Pricing_Compatibility::is_wc_version_gte_2_7() ) {
			if ( $coupon->get_exclude_sale_items() ) {

				if ( !apply_filters( 'wc_dynamic_pricing_check_coupons', true ) ) {
					return $valid;
				}

				foreach ( WC()->cart->get_cart() as $values ) {
					if ( isset( $values['discounts'] ) && isset( $values['discounts']['applied_discounts'] ) && !empty( $values['discounts']['applied_discounts'] ) ) {
						return false;
					}
				}
			}
		} else {
			if ( $coupon->exclude_sale_items() ) {
				foreach ( WC()->cart->get_cart() as $values ) {
					if ( isset( $values['discounts'] ) && isset( $values['discounts']['applied_discounts'] ) && !empty( $values['discounts']['applied_discounts'] ) ) {
						return false;
					}
				}
			}
		}


		return $valid;
	}

	public function new_account_overrides( $result, $condition ) {
		switch ( $condition['type'] ) {
			case 'apply_to':
				if ( is_array( $condition['args'] ) && isset( $condition['args']['applies_to'] ) ) {
					if ( $condition['args']['applies_to'] == 'everyone' ) {
						$result = 1;
					} elseif ( $condition['args']['applies_to'] == 'unauthenticated' ) {
						$result = 1; //The user wasn't logged in, but now will be.  Hardcode to true
					} elseif ( $condition['args']['applies_to'] == 'authenticated' ) {
						$result = 0; //The user wasn't logged in previously.
					} elseif ( $condition['args']['applies_to'] == 'roles' && isset( $condition['args']['roles'] ) && is_array( $condition['args']['roles'] ) ) {
						$result = 0;
					}
				}
				break;
			default:
				$result = 0;
				break;
		}

		return $result;
	}

	public function convert_decimals( $amount, $rule, $cart_item, $module ) {
		if ( function_exists( 'wc_format_decimal' ) ) {
			$amount = wc_format_decimal( str_replace( get_option( 'woocommerce_price_thousand_sep' ), '', $amount ) );
		}

		return $amount;
	}

	public function on_cart_loaded_from_session( $cart ) {
		$sorted_cart = array();
		if ( sizeof( $cart->cart_contents ) > 0 ) {
			foreach ( $cart->cart_contents as $cart_item_key => &$values ) {
				if ( $values === null ) {
					continue;
				}

				if ( isset( $cart->cart_contents[ $cart_item_key ]['discounts'] ) ) {
					unset( $cart->cart_contents[ $cart_item_key ]['discounts'] );
				}

				$sorted_cart[ $cart_item_key ] = &$values;
			}
		}

		if ( empty( $sorted_cart ) ) {
			return;
		}


		//Sort the cart so that the lowest priced item is discounted when using block rules.
		uasort( $sorted_cart, 'WC_Dynamic_Pricing_Cart_Query::sort_by_price' );

		$modules = apply_filters( 'wc_dynamic_pricing_load_modules', $this->modules );
		foreach ( $modules as $module ) {
			$module->adjust_cart( $sorted_cart );
		}

		// Force calculation of totals so that they are updated in mini-cart
		if ( defined( 'WC_DOING_AJAX' ) && WC_DOING_AJAX && !empty( $_REQUEST['wc-ajax'] ) && ( $_REQUEST['wc-ajax'] === 'get_refreshed_fragments' || $_REQUEST['wc-ajax'] === 'add_to_cart' || $_REQUEST['wc-ajax'] == 'remove_from_cart' ) ) {
			if ( WC_Dynamic_Pricing_Compatibility::is_wc_version_lte( '3.2.1' ) ) {
				$cart->subtotal = false;
			}
		}

	}

	public function on_calculate_totals( $cart ) {
		$sorted_cart = array();
		if ( sizeof( $cart->cart_contents ) > 0 ) {
			foreach ( $cart->cart_contents as $cart_item_key => $values ) {
				if ( $values != null ) {
					$sorted_cart[ $cart_item_key ] = $values;
				}
			}
		}

		if ( empty( $sorted_cart ) ) {
			return;
		}

		//Sort the cart so that the lowest priced item is discounted when using block rules.
		uasort( $sorted_cart, 'WC_Dynamic_Pricing_Cart_Query::sort_by_price' );

		$modules = apply_filters( 'wc_dynamic_pricing_load_modules', $this->modules );
		foreach ( $modules as $module ) {
			$module->adjust_cart( $sorted_cart );
		}

	}

	public function on_get_composite_price( $base_price, $_product ) {
		return $this->on_get_price( $base_price, $_product );
	}

	public function on_get_composite_base_price( $base_price, $_product ) {
		return $this->on_get_price( $base_price, $_product );
	}


	public function on_get_product_variation_price( $base_price, $_product ) {
		return $this->on_get_price( $base_price, $_product, false );
	}

	/**
	 * @param type $base_price
	 * @param WC_Product $_product
	 *
	 * @return float
	 * @since 2.6.1
	 *
	 */
	public function on_get_price( $base_price, $_product, $force_calculation = false ) {
		$composite_ajax = did_action( 'wp_ajax_woocommerce_show_composited_product' ) | did_action( 'wp_ajax_nopriv_woocommerce_show_composited_product' ) | did_action( 'wc_ajax_woocommerce_show_composited_product' );

		if ( empty( $_product ) || empty( $base_price ) ) {
			return $base_price;
		}

		if ( class_exists( 'WCS_ATT_Product' ) && WCS_ATT_Product::is_subscription( $_product ) ) {
			return $base_price;
		}

		$result_price = $base_price;

		if ( !$force_calculation ) {
			//Cart items are discounted when loaded from session, check to see if the call to get_price is from a cart item,
			//if so, return the price on the cart item as it currently is.
			$cart_item = WC_Dynamic_Pricing_Context::instance()->get_cart_item_for_product( $_product );

			if ( $cart_item ) {

				//If no discounts applied just return the price passed to us.
				//This is to solve subscriptions passing the sign up fee though this filter.
				if ( !isset( $cart_item['discounts'] ) ) {
					return $base_price;
				}

				//Make sure not to override the deposit amount.  It's already been configured when the cart was loaded from session.
				if ( isset( $cart_item['is_deposit'] ) ) {
					return $base_price;
				}

				$this->remove_price_filters();

				if ( WC_Dynamic_Pricing_Compatibility::is_wc_version_gte_2_7() ) {
					$cart_price = $cart_item['data']->get_price( 'edit' );
				} else {
					//Use price directly since 3.0.8 so extensions do not re-filter this value.
					//https://woothemes.zendesk.com/agent/tickets/564481
					$cart_price = $cart_item['data']->price;
				}

				$this->add_price_filters();

				return $cart_price;
			}
		}

		if ( is_object( $_product ) ) {
			$cache_id = $_product->get_id() . spl_object_hash( $_product );

			if ( !$force_calculation ) {
				if ( isset( $this->cached_adjustments[ $cache_id ] ) && $this->cached_adjustments[ $cache_id ] === false ) {
					return $base_price;
				} elseif ( isset( $this->cached_adjustments[ $cache_id ] ) && !empty( $this->cached_adjustments[ $cache_id ] ) ) {
					return $this->cached_adjustments[ $cache_id ];
				}
			}

			$adjustment_applied = false;
			$discount_price     = false;
			$working_price      = $base_price;

			$modules = apply_filters( 'wc_dynamic_pricing_load_modules', $this->modules );

			$fake_cart_item = array( 'data' => $_product );


			foreach ( $modules as $module ) {

				if ( $module->module_type == 'simple' ) {
					//Make sure we are using the price that was just discounted.

					$working_price = $module->get_product_working_price( $working_price, $_product );
					if ( $working_price !== false ) {
						$discount_price = $module->get_discounted_price_for_shop( $_product, $working_price );

						if ( ( $discount_price === 0 || $discount_price === 0.0 || $discount_price ) && $discount_price != $working_price ) {
							$working_price      = $discount_price;
							$adjustment_applied = true;

							if ( !apply_filters( 'woocommerce_dynamic_pricing_is_cumulative', true, $module->module_id, $fake_cart_item, '' ) ) {
								break;
							}
						}

					}
				}
			}

			if ( $adjustment_applied && $discount_price !== false && $discount_price != $base_price ) {
				$result_price = $discount_price;
				if ( !$force_calculation ) {
					$this->cached_adjustments[ $cache_id ] = $result_price;
				}
			} else {
				$result_price = $base_price;
				if ( !$force_calculation ) {
					$this->cached_adjustments[ $cache_id ] = false;
				}
			}


		}


		return $result_price;
	}

	/**
	 * @param type $base_price
	 * @param WC_Product $_product
	 *
	 * @return float
	 * @since 2.9.8
	 *
	 */
	private function get_discounted_price( $base_price, $_product ) {

		$id             = $_product->get_id();
		$discount_price = false;
		$working_price  = isset( $this->discounted_products[ $id ] ) ? $this->discounted_products[ $id ] : $base_price;

		$modules = apply_filters( 'wc_dynamic_pricing_load_modules', $this->modules );


		foreach ( $modules as $module ) {
			if ( $module->module_type == 'simple' ) {
				//Make sure we are using the price that was just discounted.
				$working_price = $discount_price ? $discount_price : $base_price;
				$working_price = $module->get_product_working_price( $working_price, $_product );
				if ( floatval( $working_price ) ) {
					$discount_price = $module->get_discounted_price_for_shop( $_product, $working_price );
					$cumulative     = apply_filters( 'woocommerce_dynamic_pricing_is_cumulative', true, $module->module_id, array( 'data' => $_product ), '' );
					if ( $discount_price != $base_price && !$cumulative ) {
						break;
					}
				}
			}
		}

		if ( $discount_price ) {
			return $discount_price;
		} else {
			return $base_price;
		}
	}

	/**
	 * Filters the variation price from WC_Product_Variable->get_variation_prices()
	 *
	 * @param float $price
	 * @param WC_Product_Variation $variation
	 *
	 * @return float
	 * @since 2.11.1
	 *
	 */
	public function on_get_variation_prices_price( $price, $variation ) {
		return $this->get_discounted_price( $price, $variation );
	}

	/**
	 * @param float $price
	 * @param WC_Product $product
	 * @param string $min_or_max
	 * @param string $display
	 *
	 * @return float|mixed|string
	 */
	public function on_get_variation_price( $price, $product, $min_or_max, $display ) {

		$min_price        = $price;
		$max_price        = $price;
		$tax_display_mode = get_option( 'woocommerce_tax_display_shop' );

		$children = $product->get_children();
		if ( isset( $children ) && !empty( $children ) ) {
			foreach ( $children as $variation_id ) {
				if ( $display ) {
					$variation = wc_get_product( $variation_id );
					if ( $variation ) {
						$this->remove_price_filters();

						$base_price     = $tax_display_mode == 'incl' ? wc_get_price_including_tax( $variation ) : wc_get_price_excluding_tax( $variation );
						$calc_price     = $base_price;
						$discount_price = $this->get_discounted_price( $base_price, $variation );
						if ( $discount_price && $base_price != $discount_price ) {
							$calc_price = $discount_price;
						}

						$this->add_price_filters();
					} else {
						$calc_price = '';
					}
				} else {
					$variation  = wc_get_product( $variation_id );
					$calc_price = $variation->get_price( 'view' );
				}


				if ( $min_price == null || $calc_price < $min_price ) {
					$min_price = $calc_price;
				}

				if ( $max_price == null || $calc_price > $max_price ) {
					$max_price = $calc_price;
				}
			}
		}

		if ( $min_or_max == 'min' ) {
			return $min_price;
		} elseif ( $min_or_max == 'max' ) {
			return $max_price;
		} else {
			return $price;
		}
	}

	/**
	 * Overrides the default woocommerce is on sale to ensure sale badges show properly.
	 *
	 * @param bool $is_on_sale
	 * @param WC_Product $product
	 *
	 * @return bool
	 * @since 2.10.8
	 *
	 */
	public function on_get_product_is_on_sale( $is_on_sale, $product ) {

		if ( !apply_filters( 'wc_dynamic_pricing_flag_is_on_sale', true, $product ) ) {
			return $is_on_sale;
		}

		if ( $is_on_sale ) {
			return $is_on_sale;
		}

		//TODO:  Review bundles and sales
		//if ( $product->is_type( 'bundle' ) && $product->per_product_pricing_active ) {
		//return $is_on_sale;
		//}

		if ( $product->is_type( 'variable' ) ) {
			$is_on_sale = false;

			$prices = $product->get_variation_prices();

			$regular       = array_map( 'strval', $prices['regular_price'] );
			$actual_prices = array_map( 'strval', $prices['price'] );

			$diff = array_diff_assoc( $regular, $actual_prices );

			if ( !empty( $diff ) ) {
				$is_on_sale = true;
			}
		} else {

			//1.2 - just get the price sent though the regular get_price filter.
			$dynamic_price = $product->get_price('view');

			$regular_price = $product->get_regular_price( 'view' );

			if ( empty( $regular_price ) || empty( $dynamic_price ) ) {
				return $is_on_sale;
			} else {
				$is_on_sale = $regular_price != $dynamic_price;
			}
		}

		return $is_on_sale;
	}

	//Helper functions to modify the woocommerce cart.  Called from the individual modules.
	public static function apply_cart_item_adjustment( $cart_item_key, $original_price, $adjusted_price, $module, $set_id ) {

		do_action( 'wc_memberships_discounts_disable_price_adjustments' );
		WC_Dynamic_Pricing::instance()->remove_price_filters();

		$adjusted_price = apply_filters( 'wc_dynamic_pricing_apply_cart_item_adjustment', $adjusted_price, $cart_item_key, $original_price, $module );

		//Allow extensions to stop processing of applying the discount.  Added for subscriptions signup fee compatibility
		if ( $adjusted_price === false ) {
			return;
		}


		if ( isset( WC()->cart->cart_contents[ $cart_item_key ] ) && !empty( WC()->cart->cart_contents[ $cart_item_key ] ) ) {


			$_product = WC()->cart->cart_contents[ $cart_item_key ]['data'];

			if ( apply_filters( 'wc_dynamic_pricing_get_use_sale_price', true, $_product ) ) {
				$display_price = get_option( 'woocommerce_tax_display_cart' ) == 'excl' ? wc_get_price_excluding_tax( $_product ) : wc_get_price_including_tax( $_product );
			} else {
				$display_price = get_option( 'woocommerce_tax_display_cart' ) == 'excl' ? wc_get_price_excluding_tax( $_product, array( 'price' => $original_price ) ) : wc_get_price_including_tax( $_product, array( 'price' => $original_price ) );
			}

			WC()->cart->cart_contents[ $cart_item_key ]['data']->set_price( $adjusted_price );

			if ( $_product->get_type() == 'composite' ) {
				WC()->cart->cart_contents[ $cart_item_key ]['data']->base_price = $adjusted_price;
			}

			if ( !isset( WC()->cart->cart_contents[ $cart_item_key ]['discounts'] ) ) {

				$discount_data                                           = array(
					'by'                => array( $module ),
					'set_id'            => $set_id,
					'price_base'        => $original_price,
					'display_price'     => $display_price,
					'price_adjusted'    => $adjusted_price,
					'applied_discounts' => array(
						array(
							'by'             => $module,
							'set_id'         => $set_id,
							'price_base'     => $original_price,
							'price_adjusted' => $adjusted_price
						)
					)
				);
				WC()->cart->cart_contents[ $cart_item_key ]['discounts'] = $discount_data;
			} else {

				$existing = WC()->cart->cart_contents[ $cart_item_key ]['discounts'];

				$discount_data = array(
					'by'                => $existing['by'],
					'set_id'            => $set_id,
					'price_base'        => $original_price,
					'display_price'     => $existing['display_price'],
					'price_adjusted'    => $adjusted_price,
					'applied_discounts' => $existing['applied_discounts']
				);

				WC()->cart->cart_contents[ $cart_item_key ]['discounts'] = $discount_data;


				array_push( WC()->cart->cart_contents[ $cart_item_key ]['discounts']['by'], $module );
				WC()->cart->cart_contents[ $cart_item_key ]['discounts']['applied_discounts'][] = array(
					'by'             => $module,
					'set_id'         => $set_id,
					'price_base'     => $original_price,
					'price_adjusted' => $adjusted_price
				);
			}
		}
		do_action( 'wc_memberships_discounts_enable_price_adjustments' );
		do_action( 'woocommerce_dynamic_pricing_apply_cartitem_adjustment', $cart_item_key, $original_price, $adjusted_price, $module, $set_id );
		WC_Dynamic_Pricing::instance()->add_price_filters();

	}

	/** Helper functions ***************************************************** */

	/**
	 * Get the plugin url.
	 *
	 * @access public
	 * @return string
	 */
	public static function plugin_url() {
		return untrailingslashit( plugins_url( '/', __FILE__ ) );
	}

	/**
	 * Get the plugin path.
	 *
	 * @access public
	 * @return string
	 */
	public static function plugin_path() {
		return untrailingslashit( plugin_dir_path( __FILE__ ) );
	}

}

/* Helper Functions */

function wc_dynamic_pricing_is_within_date_range( $from = '', $to = '' ) {
	// Check date range
	$from_date = empty( $from ) ? false : wc_dynamic_pricing_wp_strtotime( $from . ' ' . '00:00:00' );
	$to_date   = empty( $to ) ? false : wc_dynamic_pricing_wp_strtotime( $to . ' ' . '23:59:00' );
	$now       = current_time( 'timestamp' );

	$execute_rules = true;
	if ( $from_date && $to_date && !( $now >= $from_date && $now <= $to_date ) ) {
		$execute_rules = false;
	} elseif ( $from_date && !$to_date && !( $now >= $from_date ) ) {
		$execute_rules = false;
	} elseif ( $to_date && !$from_date && !( $now <= $to_date ) ) {
		$execute_rules = false;
	}

	return $execute_rules;
}

function wc_dynamic_pricing_wp_strtotime( $str ) {
	// This function behaves a bit like PHP's StrToTime() function, but taking into account the Wordpress site's timezone
	// CAUTION: It will throw an exception when it receives invalid input - please catch it accordingly
	// From https://mediarealm.com.au/
	$tz_string = get_option( 'timezone_string' );
	$tz_offset = get_option( 'gmt_offset', 0 );
	if ( !empty( $tz_string ) ) {
		// If site timezone option string exists, use it
		$timezone = $tz_string;
	} elseif ( $tz_offset == 0 ) {
		// get UTC offset, if it isn’t set then return UTC
		$timezone = 'UTC';
	} else {
		$timezone = $tz_offset;
		if ( substr( $tz_offset, 0, 1 ) != "-" && substr( $tz_offset, 0, 1 ) != "+" && substr( $tz_offset, 0, 1 ) != "U" ) {
			$timezone = "+" . $tz_offset;
		}
	}
	$datetime = new DateTime( $str, new DateTimeZone( $timezone ) );

	return $datetime->format( 'U' );
}

function wc_dynamic_pricing_is_groups_active() {
	$result = false;
	$result = in_array( 'groups/groups.php', (array) get_option( 'active_plugins', array() ) );
	if ( !$result && is_multisite() ) {
		$plugins = get_site_option( 'active_sitewide_plugins' );
		$result  = isset( $plugins['groups/groups.php'] );
	}

	return $result;
}

function wc_dynamic_pricing_is_memberships_active() {
	$result = false;
	$result = in_array( 'woocommerce-memberships/woocommerce-memberships.php', (array) get_option( 'active_plugins', array() ) );
	if ( !$result && is_multisite() ) {
		$plugins = get_site_option( 'active_sitewide_plugins' );
		$result  = isset( $plugins['woocommerce-memberships/woocommerce-memberships.php'] );
	}

	return $result;
}

function wc_dynamic_pricing_is_brands_active() {
	$result = false;
	$result = in_array( 'woocommerce-brands/woocommerce-brands.php', (array) get_option( 'active_plugins', array() ) );
	if ( !$result && is_multisite() ) {
		$plugins = get_site_option( 'active_sitewide_plugins' );
		$result  = isset( $plugins['woocommerce-brands/woocommerce-brands.php'] );
	}

	return $result;
}


add_filter( 'wc_dynamic_pricing_get_discount_taxonomies', 'wc_dynamic_pricing_maybe_load_product_brands' );
function wc_dynamic_pricing_maybe_load_product_brands( $taxonomies ) {
	if ( wc_dynamic_pricing_is_brands_active() ) {
		$taxonomies[] = 'product_brand';
	}

	return $taxonomies;
}

if ( ! class_exists( 'WC_Min_Max_Quantities' ) ) :

	define( 'WC_MIN_MAX_QUANTITIES', '2.4.18' ); // WRCS: DEFINED_VERSION.

	/**
	 * Min Max Quantities class.
	 */
	class WC_Min_Max_Quantities {

		/**
		 * Minimum order quantity.
		 *
		 * @var int
		 */
		public $minimum_order_quantity;

		/**
		 * Maximum order quantity.
		 *
		 * @var int
		 */
		public $maximum_order_quantity;

		/**
		 * Minimum order value.
		 *
		 * @var int
		 */
		public $minimum_order_value;

		/**
		 * Maximum order value.
		 *
		 * @var int
		 */
		public $maximum_order_value;

		/**
		 * List of excluded product titles.
		 *
		 * @var array
		 */
		public $excludes = array();

		/**
		 * Instance of addons class.
		 *
		 * @var WC_Min_Max_Quantities_Addons
		 */
		public $addons;

		/**
		 * Class instance.
		 *
		 * @var object
		 */
		private static $instance;

		/**
		 * Get the class instance.
		 */
		public static function get_instance() {
			if ( null === self::$instance ) {
				self::$instance = new self();
			}
			return self::$instance;
		}

		/**
		 * Constructor.
		 */
		public function __construct() {
			if ( ! class_exists( 'WooCommerce' ) ) {
				return;
			}

			/**
			 * Localisation.
			 */
			$this->load_plugin_textdomain();

			if ( is_admin() ) {
				include_once __DIR__ . '/includes/class-wc-min-max-quantities-admin.php';
			}

			include_once __DIR__ . '/includes/class-wc-min-max-quantities-addons.php';

			$this->addons = new WC_Min_Max_Quantities_Addons();

			$this->minimum_order_quantity = absint( get_option( 'woocommerce_minimum_order_quantity' ) );
			$this->maximum_order_quantity = absint( get_option( 'woocommerce_maximum_order_quantity' ) );
			$this->minimum_order_value    = absint( get_option( 'woocommerce_minimum_order_value' ) );
			$this->maximum_order_value    = absint( get_option( 'woocommerce_maximum_order_value' ) );

			// Check items.
			add_action( 'woocommerce_check_cart_items', array( $this, 'check_cart_items' ) );

			// Quantity selelectors (2.0+).
			add_filter( 'woocommerce_quantity_input_args', array( $this, 'update_quantity_args' ), 10, 2 );
			add_filter( 'woocommerce_available_variation', array( $this, 'available_variation' ), 10, 3 );

			// Prevent add to cart.
			add_filter( 'woocommerce_add_to_cart_validation', array( $this, 'add_to_cart' ), 10, 4 );

			// Min add to cart ajax.
			add_filter( 'woocommerce_loop_add_to_cart_link', array( $this, 'add_to_cart_link' ), 10, 2 );

			// Show a notice when items would have to be on back order because of min/max.
			add_filter( 'woocommerce_get_availability', array( $this, 'maybe_show_backorder_message' ), 10, 2 );

			add_action( 'wp_enqueue_scripts', array( $this, 'load_scripts' ) );
		}

		/**
		 * Load scripts.
		 */
		public function load_scripts() {
			// Only load on single product page and cart page.
			if ( is_product() || is_cart() ) {
				wc_enqueue_js(
					"
					jQuery( 'body' ).on( 'show_variation', function( event, variation ) {
						const step = 'undefined' !== typeof variation.step ? variation.step : 1;
						jQuery( 'form.variations_form' ).find( 'input[name=quantity]' ).prop( 'step', step ).val( variation.input_value );
					});
					"
				);
			}
		}

		/**
		 * Load Localisation files.
		 *
		 * Note: the first-loaded translation file overrides any following ones if the same translation is present.
		 *
		 * Frontend/global Locales found in:
		 * - WP_LANG_DIR/woocommerce-min-max-quantities/woocommerce-min-max-quantities-LOCALE.mo
		 * - woocommerce-min-max-quantities/woocommerce-min-max-quantities-LOCALE.mo (which if not found falls back to:)
		 * - WP_LANG_DIR/plugins/woocommerce-min-max-quantities-LOCALE.mo
		 */
		public function load_plugin_textdomain() {
			$locale = apply_filters( 'plugin_locale', get_locale(), 'woocommerce-min-max-quantities' );

			load_textdomain( 'woocommerce-min-max-quantities', WP_LANG_DIR . '/woocommerce-min-max-quantities/woocommerce-min-max-quantities-' . $locale . '.mo' );
			load_plugin_textdomain( 'woocommerce-min-max-quantities', false, plugin_basename( dirname( __FILE__ ) ) . '/' );
		}

		/**
		 * Add an error.
		 *
		 * @since 1.0.0
		 * @version 2.3.18
		 * @param string $error Error text.
		 */
		public function add_error( $error = '' ) {
			if ( $error && ! wc_has_notice( $error, 'error' ) ) {
				wc_add_notice( $error, 'error' );
			}
		}

		/**
		 * Add quantity property to add to cart button on shop loop for simple products.
		 *
		 * @param  string     $html    Add to cart link.
		 * @param  WC_Product $product Product object.
		 * @return string
		 */
		public function add_to_cart_link( $html, $product ) {

			if ( 'variable' !== $product->get_type() ) {
				$quantity_attribute = 1;
				$minimum_quantity   = absint( get_post_meta( $product->get_id(), 'minimum_allowed_quantity', true ) );
				$group_of_quantity  = absint( get_post_meta( $product->get_id(), 'group_of_quantity', true ) );

				if ( $minimum_quantity || $group_of_quantity ) {

					$quantity_attribute = $minimum_quantity;

					if ( $group_of_quantity > 0 && $minimum_quantity < $group_of_quantity ) {
						$quantity_attribute = $group_of_quantity;
					}

					$html = str_replace( '<a ', '<a data-quantity="' . $quantity_attribute . '" ', $html );
				}
			}

			return $html;
		}

		/**
		 * Get product or variation ID to check
		 *
		 * @param array $values List of values.
		 * @return int
		 */
		public function get_id_to_check( $values ) {
			if ( $values['variation_id'] ) {
				$min_max_rules = get_post_meta( $values['variation_id'], 'min_max_rules', true );

				if ( 'yes' === $min_max_rules ) {
					$checking_id = $values['variation_id'];
				} else {
					$checking_id = $values['product_id'];
				}
			} else {
				$checking_id = $values['product_id'];
			}

			return $checking_id;
		}

		/**
		 * Validate cart items against set rules
		 */
		public function check_cart_items() {
			$checked_ids         = array();
			$product_quantities  = array();
			$category_quantities = array();
			$total_quantity      = 0;
			$total_cost          = 0;
			$apply_cart_rules    = false;

			// Count items + variations first.
			foreach ( WC()->cart->get_cart() as $cart_item_key => $values ) {
				$product     = $values['data'];
				$checking_id = $this->get_id_to_check( $values );

				if ( apply_filters( 'wc_min_max_cart_quantity_do_not_count', false, $checking_id, $cart_item_key, $values ) ) {
					$values['quantity'] = 0;
				}

				if ( ! isset( $product_quantities[ $checking_id ] ) ) {
					$product_quantities[ $checking_id ] = $values['quantity'];
				} else {
					$product_quantities[ $checking_id ] += $values['quantity'];
				}

				// Do_not_count and cart_exclude from variation or product.
				$minmax_do_not_count = apply_filters( 'wc_min_max_quantity_minmax_do_not_count', ( 'yes' === get_post_meta( $checking_id, 'variation_minmax_do_not_count', true ) ? 'yes' : get_post_meta( $values['product_id'], 'minmax_do_not_count', true ) ), $checking_id, $cart_item_key, $values );

				$minmax_cart_exclude = apply_filters( 'wc_min_max_quantity_minmax_cart_exclude', ( 'yes' === get_post_meta( $checking_id, 'variation_minmax_cart_exclude', true ) ? 'yes' : get_post_meta( $values['product_id'], 'minmax_cart_exclude', true ) ), $checking_id, $cart_item_key, $values );

				if ( 'yes' !== $minmax_do_not_count && 'yes' !== $minmax_cart_exclude ) {
					$total_cost += $product->get_price() * $values['quantity'];
				}
			}

			// Check cart items.
			foreach ( WC()->cart->get_cart() as $cart_item_key => $values ) {
				$checking_id    = $this->get_id_to_check( $values );
				$terms          = get_the_terms( $values['product_id'], 'product_cat' );
				$found_term_ids = array();

				if ( $terms ) {

					foreach ( $terms as $term ) {

						if ( 'yes' === get_post_meta( $checking_id, 'minmax_category_group_of_exclude', true ) ) {
							continue;
						}

						if ( 'yes' === get_post_meta( $checking_id, 'variation_minmax_category_group_of_exclude', true ) ) {
							continue;
						}

						if ( in_array( $term->term_id, $found_term_ids, true ) ) {
							continue;
						}

						$found_term_ids[]                      = $term->term_id;
						$category_quantities[ $term->term_id ] = isset( $category_quantities[ $term->term_id ] ) ? $category_quantities[ $term->term_id ] + $values['quantity'] : $values['quantity'];

						// Record count in parents of this category too.
						$parents = get_ancestors( $term->term_id, 'product_cat' );

						foreach ( $parents as $parent ) {
							if ( in_array( $parent, $found_term_ids, true ) ) {
								continue;
							}

							$found_term_ids[]               = $parent;
							$category_quantities[ $parent ] = isset( $category_quantities[ $parent ] ) ? $category_quantities[ $parent ] + $values['quantity'] : $values['quantity'];
						}
					}
				}

				// Check item rules once per product ID.
				if ( in_array( $checking_id, $checked_ids, true ) ) {
					continue;
				}

				$product = $values['data'];

				// Do_not_count and cart_exclude from variation or product.
				$minmax_do_not_count = apply_filters( 'wc_min_max_quantity_minmax_do_not_count', ( 'yes' === get_post_meta( $checking_id, 'variation_minmax_do_not_count', true ) ? 'yes' : get_post_meta( $values['product_id'], 'minmax_do_not_count', true ) ), $checking_id, $cart_item_key, $values );

				$minmax_cart_exclude = apply_filters( 'wc_min_max_quantity_minmax_cart_exclude', ( 'yes' === get_post_meta( $checking_id, 'variation_minmax_cart_exclude', true ) ? 'yes' : get_post_meta( $values['product_id'], 'minmax_cart_exclude', true ) ), $checking_id, $cart_item_key, $values );

				if ( 'yes' === $minmax_do_not_count || 'yes' === $minmax_cart_exclude ) {
					// Do not count.
					$this->excludes[] = $product->get_title();

				} else {
					$total_quantity += $product_quantities[ $checking_id ];
				}

				if ( 'yes' !== $minmax_cart_exclude ) {
					$apply_cart_rules = true;
				}

				$checked_ids[] = $checking_id;

				if ( $values['variation_id'] ) {
					$min_max_rules = get_post_meta( $values['variation_id'], 'min_max_rules', true );

					// Variation level min max rules enabled.
					if ( 'yes' === $min_max_rules ) {
						$minimum_quantity = absint( apply_filters( 'wc_min_max_quantity_minimum_allowed_quantity', get_post_meta( $values['variation_id'], 'variation_minimum_allowed_quantity', true ), $values['variation_id'], $cart_item_key, $values ) );

						$maximum_quantity = absint( apply_filters( 'wc_min_max_quantity_maximum_allowed_quantity', get_post_meta( $values['variation_id'], 'variation_maximum_allowed_quantity', true ), $values['variation_id'], $cart_item_key, $values ) );

						$group_of_quantity = absint( apply_filters( 'wc_min_max_quantity_group_of_quantity', get_post_meta( $values['variation_id'], 'variation_group_of_quantity', true ), $values['variation_id'], $cart_item_key, $values ) );
					} else {
						$minimum_quantity = absint( apply_filters( 'wc_min_max_quantity_minimum_allowed_quantity', get_post_meta( $values['product_id'], 'minimum_allowed_quantity', true ), $values['product_id'], $cart_item_key, $values ) );

						$maximum_quantity = absint( apply_filters( 'wc_min_max_quantity_maximum_allowed_quantity', get_post_meta( $values['product_id'], 'maximum_allowed_quantity', true ), $values['product_id'], $cart_item_key, $values ) );

						$group_of_quantity = absint( apply_filters( 'wc_min_max_quantity_group_of_quantity', get_post_meta( $values['product_id'], 'group_of_quantity', true ), $values['product_id'], $cart_item_key, $values ) );
					}
				} else {
					$minimum_quantity = absint( apply_filters( 'wc_min_max_quantity_minimum_allowed_quantity', get_post_meta( $checking_id, 'minimum_allowed_quantity', true ), $checking_id, $cart_item_key, $values ) );

					$maximum_quantity = absint( apply_filters( 'wc_min_max_quantity_maximum_allowed_quantity', get_post_meta( $checking_id, 'maximum_allowed_quantity', true ), $checking_id, $cart_item_key, $values ) );

					$group_of_quantity = absint( apply_filters( 'wc_min_max_quantity_group_of_quantity', get_post_meta( $checking_id, 'group_of_quantity', true ), $checking_id, $cart_item_key, $values ) );
				}

				$this->check_rules( $product, $product_quantities[ $checking_id ], $minimum_quantity, $maximum_quantity, $group_of_quantity );
			}

			// Cart rules.
			if ( $apply_cart_rules ) {

				$excludes = '';

				if ( count( $this->excludes ) > 0 ) {
					$excludes = ' (' . __( 'excludes ', 'woocommerce-min-max-quantities' ) . implode( ', ', $this->excludes ) . ')';
				}

				if ( $this->minimum_order_quantity > 0 && $total_quantity < $this->minimum_order_quantity ) {
					/* translators: %d: Minimum amount of items in the cart */
					$this->add_error( sprintf( __( 'The minimum required items in cart is %d. Please add more items to your cart', 'woocommerce-min-max-quantities' ), $this->minimum_order_quantity ) . $excludes );

					return;

				}

				if ( $this->maximum_order_quantity > 0 && $total_quantity > $this->maximum_order_quantity ) {
					/* translators: %d: Maximum amount of items in the cart */
					$this->add_error( sprintf( __( 'The maximum allowed order quantity is %d. Please remove some items from your cart.', 'woocommerce-min-max-quantities' ), $this->maximum_order_quantity ) );

					return;

				}

				// Check cart value.
				if ( $this->minimum_order_value && $total_cost && $total_cost < $this->minimum_order_value ) {
					/* translators: %s: Minimum order value */
					$this->add_error( sprintf( __( 'The minimum required order value is %s. Please add more items to your cart', 'woocommerce-min-max-quantities' ), wc_price( $this->minimum_order_value ) ) . $excludes );

					return;
				}

				if ( $this->maximum_order_value && $total_cost && $total_cost > $this->maximum_order_value ) {
					/* translators: %s: Maximum order value */
					$this->add_error( sprintf( __( 'The maximum allowed order value is %s. Please remove some items from your cart.', 'woocommerce-min-max-quantities' ), wc_price( $this->maximum_order_value ) ) );

					return;
				}
			}

			// Check category rules.
			foreach ( $category_quantities as $category => $quantity ) {

				$group_of_quantity = intval( version_compare( WC_VERSION, '3.6', 'ge' ) ? get_term_meta( $category, 'group_of_quantity', true ) : get_woocommerce_term_meta( $category, 'group_of_quantity', true ) );

				if ( $group_of_quantity > 0 && ( intval( $quantity ) % intval( $group_of_quantity ) > 0 ) ) {

					$term          = get_term_by( 'id', $category, 'product_cat' );
					$product_names = array();

					foreach ( WC()->cart->get_cart() as $cart_item_key => $values ) {

						// If exclude is enable, skip.
						if ( 'yes' === get_post_meta( $values['product_id'], 'minmax_category_group_of_exclude', true ) || 'yes' === get_post_meta( $values['variation_id'], 'variation_minmax_category_group_of_exclude', true ) ) {
							continue;
						}

						if ( has_term( $category, 'product_cat', $values['product_id'] ) ) {
							$product_names[] = $values['data']->get_title();
						}
					}

					if ( $product_names ) {
						/* translators: %1$s: Category name, %2$s: Comma separated list of product names, %3$d: Group amount */
						$this->add_error( sprintf( __( 'Items in the <strong>%1$s</strong> category (<em>%2$s</em>) must be bought in groups of %3$d. Please add or remove the items to continue.', 'woocommerce-min-max-quantities' ), $term->name, implode( ', ', $product_names ), $group_of_quantity, $group_of_quantity - ( $quantity % $group_of_quantity ) ) );
						return;
					}
				}
			}
		}

		/**
		 * If the minimum allowed quantity for purchase is lower then the current stock, we need to
		 * let the user know that they are on backorder, or out of stock.
		 *
		 * @param array      $args    List of arguments.
		 * @param WC_Product $product Product object.
		 */
		public function maybe_show_backorder_message( $args, $product ) {
			if ( ! $product->managing_stock() ) {
				return $args;
			}

			// Figure out what our minimum_quantity is.
			$product_id = $product->get_id();
			if ( 'WC_Product_Variation' === get_class( $product ) ) {
				$variation_id  = ( version_compare( WC_VERSION, '3.0', '<' ) && isset( $product->variation_id ) ) ? $product->variation_id : $product->get_id();
				$min_max_rules = get_post_meta( $variation_id, 'min_max_rules', true );
				if ( 'yes' === $min_max_rules ) {
					$minimum_quantity = absint( get_post_meta( $variation_id, 'variation_minimum_allowed_quantity', true ) );
				} else {
					$minimum_quantity = absint( get_post_meta( $product_id, 'minimum_allowed_quantity', true ) );
				}
			} else {
				$minimum_quantity = absint( get_post_meta( $product_id, 'minimum_allowed_quantity', true ) );
			}

			// If the minimum quantity allowed for purchase is smaller then the amount in stock, we need
			// clearer messaging.
			if ( $minimum_quantity > 0 && $product->get_stock_quantity() < $minimum_quantity ) {
				if ( $product->backorders_allowed() ) {
					return array(
						'availability' => __( 'Available on backorder', 'woocommerce-min-max-quantities' ),
						'class'        => 'available-on-backorder',
					);
				} else {
					return array(
						'availability' => __( 'Out of stock', 'woocommerce-min-max-quantities' ),
						'class'        => 'out-of-stock',
					);
				}
			}

			return $args;
		}

		/**
		 * Add respective error message depending on rules checked.
		 *
		 * @param WC_Product $product           Product object.
		 * @param int        $quantity          Quantity to check.
		 * @param int        $minimum_quantity  Minimum quantity.
		 * @param int        $maximum_quantity  Maximum quanitty.
		 * @param int        $group_of_quantity Group quantity.
		 * @return void
		 */
		public function check_rules( $product, $quantity, $minimum_quantity, $maximum_quantity, $group_of_quantity ) {
			$parent_id = $product->is_type( 'variation' ) ? ( version_compare( WC_VERSION, '3.0', '<' ) ? $product->parent_id : $product->get_parent_id() ) : $product->get_id();

			$allow_combination = 'yes' === get_post_meta( $parent_id, 'allow_combination', true );

			if ( $minimum_quantity > 0 && $quantity < $minimum_quantity ) {

				if ( $allow_combination && ( $product->is_type( 'variation' ) || $product->is_type( 'variable' ) ) ) {
					/* translators: %1$s: Product name, %2$s: Minimum order quantity */
					$this->add_error( sprintf( __( 'The minimum order quantity for %1$s is %2$s - please increase the quantity in your cart or add additional variation of this product.', 'woocommerce-min-max-quantities' ), $product->get_title(), $minimum_quantity ) );
				} else {
					/* translators: %1$s: Product name, %2$s: Minimum order quantity */
					$this->add_error( sprintf( __( 'The minimum order quantity for %1$s is %2$s - please increase the quantity in your cart.', 'woocommerce-min-max-quantities' ), $product->get_title(), $minimum_quantity ) );
				}
			} elseif ( $maximum_quantity > 0 && $quantity > $maximum_quantity ) {
				if ( $allow_combination && ( $product->is_type( 'variation' ) || $product->is_type( 'variable' ) ) ) {
					/* translators: %1$s: Product name, %2$s: Maximum order quantity */
					$this->add_error( sprintf( __( 'The maximum allowed quantity for %1$s is %2$s - please decrease the quantity in your cart or remove additional variation of this product.', 'woocommerce-min-max-quantities' ), $product->get_title(), $maximum_quantity ) );
				} else {
					/* translators: %1$s: Product name, %2$s: Maximum order quantity */
					$this->add_error( sprintf( __( 'The maximum allowed quantity for %1$s is %2$s - please decrease the quantity in your cart.', 'woocommerce-min-max-quantities' ), $product->get_title(), $maximum_quantity ) );
				}
			}

			if ( $group_of_quantity > 0 && ( intval( $quantity ) % intval( $group_of_quantity ) > 0 ) ) {
				/* translators: %1$s: Product name, %2$d: Group amount */
				$this->add_error( sprintf( __( '%1$s must be bought in groups of %2$d. Please add or decrease items to continue.', 'woocommerce-min-max-quantities' ), $product->get_title(), $group_of_quantity, $group_of_quantity - ( $quantity % $group_of_quantity ) ) );
			}
		}

		/**
		 * Add to cart validation
		 *
		 * @param  mixed $pass         Filter value.
		 * @param  mixed $product_id   Product ID.
		 * @param  mixed $quantity     Quantity.
		 * @param  int   $variation_id Variation ID (default none).
		 * @return mixed
		 */
		public function add_to_cart( $pass, $product_id, $quantity, $variation_id = 0 ) {
			$rule_for_variaton = false;

			$allow_combination = 'yes' === get_post_meta( $product_id, 'allow_combination', true );

			if ( 0 < $variation_id && $allow_combination ) {
				return $pass;
			}

			// Product level.
			if ( $variation_id ) {

				$min_max_rules = get_post_meta( $variation_id, 'min_max_rules', true );

				if ( 'yes' === $min_max_rules ) {

					$maximum_quantity  = absint( get_post_meta( $variation_id, 'variation_maximum_allowed_quantity', true ) );
					$minimum_quantity  = absint( get_post_meta( $variation_id, 'variation_minimum_allowed_quantity', true ) );
					$rule_for_variaton = true;

				} else {

					$maximum_quantity = absint( get_post_meta( $product_id, 'maximum_allowed_quantity', true ) );
					$minimum_quantity = absint( get_post_meta( $product_id, 'minimum_allowed_quantity', true ) );

				}
			} else {

				$maximum_quantity = absint( get_post_meta( $product_id, 'maximum_allowed_quantity', true ) );
				$minimum_quantity = absint( get_post_meta( $product_id, 'minimum_allowed_quantity', true ) );

			}

			$total_quantity = $quantity;

			// Count items.
			foreach ( WC()->cart->get_cart() as $cart_item_key => $values ) {

				$checking_id = $values['variation_id'] ? $values['variation_id'] : $values['product_id'];

				if ( apply_filters( 'wc_min_max_cart_quantity_do_not_count', false, $checking_id, $cart_item_key, $values ) ) {
					continue;
				}

				if ( $rule_for_variaton ) {

					if ( $values['variation_id'] === $variation_id ) {

						$total_quantity += $values['quantity'];
					}
				} else {

					if ( $values['product_id'] === $product_id ) {

						$total_quantity += $values['quantity'];
					}
				}
			}

			if ( isset( $maximum_quantity ) && $maximum_quantity > 0 ) {
				if ( $total_quantity > 0 && $total_quantity > $maximum_quantity ) {

					$_product = wc_get_product( $product_id );

					/* translators: %1$s: Product name, %2$d: Maximum quantity, %3$s: Currenty quantity */
					$message = sprintf( __( 'The maximum allowed quantity for %1$s is %2$d (you currently have %3$s in your cart).', 'woocommerce-min-max-quantities' ), $_product->get_title(), $maximum_quantity, $total_quantity - $quantity );

					// If quantity requirement is met, show cart link.
					if ( intval( $maximum_quantity ) <= intval( $total_quantity - $quantity ) ) {
						/* translators: %1$s: Product name, %2$d: Maximum quantity, %3$s: Currenty quantity, %4$s: Cart link */
						$message = sprintf( __( 'The maximum allowed quantity for %1$s is %2$d (you currently have %3$s in your cart). <a href="%4$s" class="woocommerce-min-max-quantities-error-cart-link button wc-forward">View cart</a>', 'woocommerce-min-max-quantities' ), $_product->get_title(), $maximum_quantity, $total_quantity - $quantity, esc_url( wc_get_cart_url() ) );
					}

					$this->add_error( $message );

					$pass = false;
				}
			}

			if ( isset( $minimum_quantity ) && $minimum_quantity > 0 ) {
				if ( $total_quantity < $minimum_quantity ) {

					$_product = wc_get_product( $product_id );

					/* translators: %1$s: Product name, %2$d: Minimum quantity, %3$s: Currenty quantity */
					$this->add_error( sprintf( __( 'The minimum allowed quantity for %1$s is %2$d (you currently have %3$s in your cart).', 'woocommerce-min-max-quantities' ), $_product->get_title(), $minimum_quantity, $total_quantity - $quantity ) );

					$pass = true;
				}
			}

			// If product level quantity are not set then check global order quantity.
			if ( empty( $maximum_quantity ) && empty( $minimum_quantity ) ) {
				$total_quantity = intval( WC()->cart->get_cart_contents_count() + $quantity );

				if ( $this->maximum_order_quantity && $this->maximum_order_quantity > 0 ) {
					if ( $total_quantity > $this->maximum_order_quantity ) {
						if ( 0 === $total_quantity - $quantity ) {
							/* translators: %d: Maximum quantity in cart */
							$this->add_error( sprintf( __( 'The maximum allowed items in cart is %d.', 'woocommerce-min-max-quantities' ), $this->maximum_order_quantity ) );
						} else {
							/* translators: %1$d: Maximum quanity, %2$d: Current quantity */
							$message = sprintf( __( 'The maximum allowed items in cart is %1$d (you currently have %2$d in your cart).', 'woocommerce-min-max-quantities' ), $this->maximum_order_quantity, $total_quantity - $quantity );

							if ( intval( $this->maximum_order_quantity ) <= intval( $total_quantity - $quantity ) ) {
								/* translators: %1$d: Maximum quanity, %2$d: Current quantity, %3$s: Cart link */
								$message = sprintf( __( 'The maximum allowed items in cart is %1$d (you currently have %2$d in your cart). <a href="%3$s" class="woocommerce-min-max-quantities-error-cart-link button wc-forward">View cart</a>', 'woocommerce-min-max-quantities' ), $this->maximum_order_quantity, $total_quantity - $quantity, esc_url( wc_get_cart_url() ) );
							}

							$this->add_error( $message );
						}

						$pass = false;
					}
				}
			}

			return $pass;
		}

		/**
		 * Updates the quantity arguments.
		 *
		 * @param array      $data    List of data to update.
		 * @param WC_Product $product Product object.
		 * @return array
		 */
		public function update_quantity_args( $data, $product ) {
			// Multiple shipping address product plugin compat
			// don't update the quantity args when on set multiple address page.
			if ( $this->addons->is_multiple_shipping_address_page() ) {
				return $data;
			}

			$group_of_quantity = get_post_meta( $product->get_id(), 'group_of_quantity', true );
			$minimum_quantity  = get_post_meta( $product->get_id(), 'minimum_allowed_quantity', true );
			$maximum_quantity  = get_post_meta( $product->get_id(), 'maximum_allowed_quantity', true );
			$allow_combination = 'yes' === get_post_meta( version_compare( WC_VERSION, '3.0', '<' ) ? $product->get_id() : $product->get_parent_id(), 'allow_combination', true );

			/*
			* If its a variable product and allow combination is enabled,
			* we don't need to set the quantity to default minimum.
			*/
			if ( $allow_combination && $product->is_type( 'variation' ) ) {
				return $data;
			}

			// If variable product, only apply in cart.
			$variation_id = ( version_compare( WC_VERSION, '3.0', '<' ) && isset( $product->variation_id ) ) ? $product->variation_id : $product->get_id();

			if ( is_cart() && $product->is_type( 'variation' ) ) {
				$parent_variable_id = version_compare( WC_VERSION, '3.0', '<' ) ? $product->get_id() : $product->get_parent_id();

				$group_of_quantity = get_post_meta( $parent_variable_id, 'group_of_quantity', true );
				$minimum_quantity  = get_post_meta( $parent_variable_id, 'minimum_allowed_quantity', true );
				$maximum_quantity  = get_post_meta( $parent_variable_id, 'maximum_allowed_quantity', true );
				$allow_combination = 'yes' === get_post_meta( $parent_variable_id, 'allow_combination', true );

				$min_max_rules = get_post_meta( $variation_id, 'min_max_rules', true );

				if ( 'no' === $min_max_rules || empty( $min_max_rules ) ) {
					$min_max_rules = false;

				} else {
					$min_max_rules = true;

				}

				$variation_minimum_quantity  = get_post_meta( $variation_id, 'variation_minimum_allowed_quantity', true );
				$variation_maximum_quantity  = get_post_meta( $variation_id, 'variation_maximum_allowed_quantity', true );
				$variation_group_of_quantity = get_post_meta( $variation_id, 'variation_group_of_quantity', true );

				// Override product level.
				if ( $min_max_rules && $variation_minimum_quantity ) {
					$minimum_quantity = $variation_minimum_quantity;

				}

				// Override product level.
				if ( $min_max_rules && $variation_maximum_quantity ) {
					$maximum_quantity = $variation_maximum_quantity;
				}

				// Override product level.
				if ( $min_max_rules && $variation_group_of_quantity ) {
					$group_of_quantity = $variation_group_of_quantity;

				}
			}

			if ( $minimum_quantity ) {

				if ( $product->managing_stock() && ! $product->backorders_allowed() && absint( $minimum_quantity ) > $product->get_stock_quantity() ) {
					$data['min_value'] = $product->get_stock_quantity();

				} else {
					$data['min_value'] = $minimum_quantity;
				}
			}

			if ( $maximum_quantity ) {

				if ( $product->managing_stock() && $product->backorders_allowed() ) {
					$data['max_value'] = $maximum_quantity;

				} elseif ( $product->managing_stock() && absint( $maximum_quantity ) > $product->get_stock_quantity() ) {
					$data['max_value'] = $product->get_stock_quantity();

				} else {
					$data['max_value'] = $maximum_quantity;
				}
			}

			if ( $group_of_quantity ) {
				$data['step'] = 1;

				// If both minimum and maximum quantity are set, make sure both are equally divisble by qroup of quantity.
				if ( $maximum_quantity && $minimum_quantity ) {

					if ( absint( $maximum_quantity ) % absint( $group_of_quantity ) === 0 && absint( $minimum_quantity ) % absint( $group_of_quantity ) === 0 ) {
						$data['step'] = $group_of_quantity;

					}
				} elseif ( ! $maximum_quantity || absint( $maximum_quantity ) % absint( $group_of_quantity ) === 0 ) {

					$data['step'] = $group_of_quantity;
				}

				// Set a new minimum if group of is set but not minimum.
				if ( ! $minimum_quantity ) {
					$data['min_value'] = $group_of_quantity;
				}
			}

			// Don't apply for cart or checkout as cart/checkout form has qty already pre-filled.
			if ( ! is_cart() && ! is_checkout() ) {
				$data['input_value'] = ! empty( $minimum_quantity ) ? $minimum_quantity : $data['input_value'];
			}

			return $data;
		}

		/**
		 * Adds variation min max settings to the localized variation parameters to be used by JS.
		 *
		 * @param array  $data      Available variation data.
		 * @param object $product   Product object.
		 * @param object $variation Variation object.
		 * @return array $data
		 */
		public function available_variation( $data, $product, $variation ) {
			$variation_id = ( version_compare( WC_VERSION, '3.0', '<' ) && isset( $variation->variation_id ) ) ? $variation->variation_id : $variation->get_id();

			$min_max_rules = get_post_meta( $variation_id, 'min_max_rules', true );

			if ( 'no' === $min_max_rules || empty( $min_max_rules ) ) {
				$min_max_rules = false;

			} else {
				$min_max_rules = true;

			}

			$minimum_quantity  = get_post_meta( $product->get_id(), 'minimum_allowed_quantity', true );
			$maximum_quantity  = get_post_meta( $product->get_id(), 'maximum_allowed_quantity', true );
			$group_of_quantity = get_post_meta( $product->get_id(), 'group_of_quantity', true );
			$allow_combination = 'yes' === get_post_meta( $product->get_id(), 'allow_combination', true );

			$variation_minimum_quantity  = get_post_meta( $variation_id, 'variation_minimum_allowed_quantity', true );
			$variation_maximum_quantity  = get_post_meta( $variation_id, 'variation_maximum_allowed_quantity', true );
			$variation_group_of_quantity = get_post_meta( $variation_id, 'variation_group_of_quantity', true );

			// Override product level.
			if ( $variation->managing_stock() ) {
				$product = $variation;

			}

			// Override product level.
			if ( $min_max_rules && $variation_minimum_quantity ) {
				$minimum_quantity = $variation_minimum_quantity;

			}

			// Override product level.
			if ( $min_max_rules && $variation_maximum_quantity ) {
				$maximum_quantity = $variation_maximum_quantity;
			}

			// Override product level.
			if ( $min_max_rules && $variation_group_of_quantity ) {
				$group_of_quantity = $variation_group_of_quantity;

			}

			if ( $minimum_quantity ) {

				if ( $product->managing_stock() && $product->backorders_allowed() && absint( $minimum_quantity ) > $product->get_stock_quantity() ) {
					$data['min_qty'] = $product->get_stock_quantity();

				} else {
					$data['min_qty'] = $minimum_quantity;
				}
			}

			if ( $maximum_quantity ) {

				if ( $product->managing_stock() && $product->backorders_allowed() ) {
					$data['max_qty'] = $maximum_quantity;

				} elseif ( $product->managing_stock() && absint( $maximum_quantity ) > $product->get_stock_quantity() ) {
					$data['max_qty'] = $product->get_stock_quantity();

				} else {
					$data['max_qty'] = $maximum_quantity;
				}
			}

			if ( $group_of_quantity ) {
				$data['step'] = 1;

				// If both minimum and maximum quantity are set, make sure both are equally divisible by qroup of quantity.
				if ( $maximum_quantity && $minimum_quantity ) {

					if ( absint( $maximum_quantity ) % absint( $group_of_quantity ) === 0 && absint( $minimum_quantity ) % absint( $group_of_quantity ) === 0 ) {
						$data['step'] = $group_of_quantity;

					}
				} elseif ( ! $maximum_quantity || absint( $maximum_quantity ) % absint( $group_of_quantity ) === 0 ) {

					$data['step'] = $group_of_quantity;
				}

				// Set the minimum only when minimum is not set.
				if ( ! $minimum_quantity ) {
					$data['min_qty'] = $group_of_quantity;
				}
			}

			// Don't apply for cart as cart has qty already pre-filled.
			if ( ! is_cart() ) {
				if ( ! $minimum_quantity && $group_of_quantity ) {
					$data['input_value'] = $group_of_quantity;
				} else {
					$data['input_value'] = ! empty( $minimum_quantity ) ? $minimum_quantity : 1;
				}

				if ( $allow_combination ) {
					$data['input_value'] = 1;
					$data['min_qty']     = 1;
					$data['max_qty']     = '';
					$data['step']        = 1;
				}
			}

			return $data;
		}
	}

	add_action( 'plugins_loaded', array( 'WC_Min_Max_Quantities', 'get_instance' ) );

endif;
