<?php

/**
 * The main plugin file for Optimizeform Product Table.
 *
 * This file is included during the WordPress bootstrap process if the plugin is active.
 *
 * @package   OptimizeForm/woocommerce-product-table
 * @author    OptimizeForm <info@optimizeform.com>
 * @license   GPL-3.0
 * @copyright OptimizeForm
 *
 * @wordpress-plugin
 * Plugin Name:     Optimizeform Product Table
 * Plugin URI:      https://optimizeform.com
 * Description:     Display and purchase WooCommerce products from a searchable and sortable table. Filter by anything.
 * Version:         1.5.3
 * Author:          OptimizeForm
 * Author URI:      https://optimizeform.com
 * Text Domain:     woocommerce-product-table
 * Domain Path:     /languages
 *
 * WC requires at least: 3.4
 * WC tested up to: 4.2
 *
 * Copyright:       OptimizeForm
 * License:         GNU General Public License v3.0
 * License URI:     http://www.gnu.org/licenses/gpl-3.0.html
 */
namespace OptimizeForm\Plugin\WC_Product_Table;

// Prevent direct file access
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

const PLUGIN_FILE    = __FILE__;
const PLUGIN_VERSION = '1.5.3';

// Include autoloader.
require_once __DIR__ . '/vendor/autoload.php';

/**
 * Helper function to access the shared plugin instance.
 *
 * @return \WC_Product_Table_Plugin The plugin instance.
 */
function wpt() {
    return Plugin_Factory::create( PLUGIN_FILE, PLUGIN_VERSION );
}

function wc_product_table() {
    _deprecated_function( __FUNCTION__, '2.6.2', 'OptimizeForm\\Plugin\\WC_Product_Table->wpt()' );
    return wpt();
}

// Load the plugin.
wpt()->register();

