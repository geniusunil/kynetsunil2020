<?php

/**
 * Interface for the product table data.
 *
 * Each column in the product table implements this interface to retrieve its data.
 *
 * @package   OptimizeForm/woocommerce-product-table
 * @author    OptimizeForm <info@optimizeform.com>
 * @license   GPL-3.0
 * @copyright OptimizeForm
 */
interface Product_Table_Data {

    public function get_data();

    public function get_filter_data();

    public function get_sort_data();

}
