<?php

/**
 * Gets data for the name column.
 *
 * @package   OptimizeForm/woocommerce-product-table
 * @author    OptimizeForm <info@optimizeform.com>
 * @license   GPL-3.0
 * @copyright OptimizeForm
 */
class Product_Table_Data_Name extends Abstract_Product_Table_Data {

    public function get_data() {
        $name = WCPT_Util::get_product_name( $this->product );

        if ( array_intersect( array( 'all', 'name' ), $this->links ) ) {
            $name = WCPT_Util::format_product_link( $this->product, $name );
        }
        return apply_filters( 'wc_product_table_data_name', $name, $this->product );
    }

}
