<?php

/**
 * Gets data for the SKU column.
 *
 * @package   OptimizeForm/woocommerce-product-table
 * @author    OptimizeForm <info@optimizeform.com>
 * @license   GPL-3.0
 * @copyright OptimizeForm
 */
class Product_Table_Data_Sku extends Abstract_Product_Table_Data {

    public function get_data() {
        $sku = $this->product->get_sku();

        if ( $sku && array_intersect( array( 'all', 'sku' ), $this->links ) ) {
            $sku = WCPT_Util::format_product_link( $this->product, $sku );
        }
        return apply_filters( 'wc_product_table_data_sku', $sku, $this->product );
    }

}
