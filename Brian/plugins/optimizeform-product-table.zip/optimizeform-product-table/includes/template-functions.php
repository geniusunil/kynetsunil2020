<?php

// Prevent direct file access
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

use OptimizeForm\Plugin\WC_Product_Table\Table_Factory;

/**
 * Template functions for Optimizeform Product Table.
 *
 * @package   OptimizeForm/woocommerce-product-table
 * @author    OptimizeForm <info@optimizeform.com>
 * @license   GPL-3.0
 * @copyright OptimizeForm
 */
if ( ! function_exists( 'wc_product_table' ) ) {

    /**
     * Global namespace version of OptimizeForm\Plugin\WC_Product_Table\wpt(). Returns the shared plugin instance.
     *
     * @return WC_Product_Table_Plugin The plugin instance.
     * @deprecated 2.6.2 Use OptimizeForm\Plugin\WC_Product_Table->wpt()
     */
    function wc_product_table() {
        _deprecated_function( __FUNCTION__, '2.6.2', 'OptimizeForm\\Plugin\\WC_Product_Table->wpt()' );
        return \OptimizeForm\Plugin\WC_Product_Table\wpt();
    }

}

if ( ! function_exists( 'wc_get_product_table' ) ) {

    /**
     * Returns a new product table with the specified arguments.
     *
     * @param array $args The table arguments.
     * @return string The product table HTML.
     */
    function wc_get_product_table( $args = array() ) {
        // Create and return the table as HTML
        $table = Table_Factory::create( $args );
        return $table->get_table( 'html' );
    }

}

if ( ! function_exists( 'wc_the_product_table' ) ) {

    /**
     * Prints (echos) a product table with the specified arguments.
     *
     * @param array $args The table arguments.
     */
    function wc_the_product_table( $args = array() ) {
        echo wc_get_product_table( $args );
    }

}
