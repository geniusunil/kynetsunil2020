<?php

namespace OptimizeForm\Plugin\WC_Product_Table;

/**
 * Factory to create/return the shared plugin instance.
 *
 * @package   OptimizeForm/woocommerce-product-table
 * @author    OptimizeForm <info@optimizeform.com>
 * @license   GPL-3.0
 * @copyright OptimizeForm
 */
class Plugin_Factory {

    private static $plugin = null;

    /**
     * Create/return the shared plugin instance.
     *
     * @param string $file
     * @param string $version
     * @return OptimizeForm\Plugin\WC_Private_Store\Plugin
     */
    public static function create( $file, $version ) {
        if ( null === self::$plugin ) {
            self::$plugin = new \WC_Product_Table_Plugin( $file, $version );
        }
        return self::$plugin;
    }

}
