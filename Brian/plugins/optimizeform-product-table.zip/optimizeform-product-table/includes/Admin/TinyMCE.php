<?php

namespace OptimizeForm\Plugin\WC_Product_Table\Admin;

use OptimizeForm\WPT_Lib\Registerable,
    OptimizeForm\WPT_Lib\Service,
    OptimizeForm\WPT_Lib\Util;

/**
 * This class handles our TinyMCE toolbar button.
 *
 * @package   OptimizeForm/woocommerce-product-table
 * @author    OptimizeForm <info@optimizeform.com>
 * @license   GPL-3.0
 * @copyright OptimizeForm
 */
class TinyMCE implements Registerable, Service {

    public function register() {
        if ( ! \current_user_can( 'edit_posts' ) && ! \current_user_can( 'edit_pages' ) ) {
            return;
        }

        if ( 'true' !== \get_user_option( 'rich_editing' ) ) {
            return;
        }

        \add_filter( 'mce_external_plugins', array( $this, 'add_tinymce_plugin' ) );
        \add_filter( 'mce_buttons_2', array( $this, 'add_tinymce_button' ) );
    }

    public function add_tinymce_plugin( $plugins ) {
        $plugins['producttable'] = \WCPT_Util::get_asset_url( 'js/admin/tinymce-product-table' . Util::get_script_suffix() . '.js' );
        return $plugins;
    }

    public function add_tinymce_button( $buttons ) {
        \array_push( $buttons, 'producttable' );
        return $buttons;
    }

}
