<?php

namespace OptimizeForm\WPT_Lib;

/**
 * Marker interface to denote a service.
 *
 * @package   OptimizeForm/OptimizeForm-lib
 * @author    OptimizeForm <info@optimizeform.com>
 * @license   GPL-3.0
 * @copyright OptimizeForm
 * @version   1.0
 */
interface Service {

}
