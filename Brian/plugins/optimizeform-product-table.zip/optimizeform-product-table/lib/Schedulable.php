<?php

namespace OptimizeForm\WPT_Lib;

/**
 * Something that can be scheduled.
 *
 * @package   OptimizeForm/OptimizeForm-lib
 * @author    OptimizeForm <info@optimizeform.com>
 * @license   GPL-3.0
 * @copyright OptimizeForm
 * @version   1.0
 */
interface Schedulable {

    public function schedule();

    public function unschedule();

}
