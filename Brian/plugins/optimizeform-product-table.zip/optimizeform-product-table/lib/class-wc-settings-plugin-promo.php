<?php

use OptimizeForm\WPT_Lib\Registerable;

if ( ! class_exists( 'WC_OptimizeForm_Plugin_Promo' ) ) {

    /**
     * Provides functions to add the plugin promo to the plugin settings page in the WordPress admin.
     *
     * @package   OptimizeForm/OptimizeForm-lib
     * @author    OptimizeForm <info@optimizeform.com>
     * @license   GPL-3.0
     * @copyright OptimizeForm
     * @version   1.3.3
     */
    class WC_OptimizeForm_Plugin_Promo implements Registerable {

        private $plugin_id;
        private $plugin_file;
        private $section_slug;
        private $settings_page;

        public function __construct( $plugin_id, $plugin_file, $section_slug, $settings_page = false ) {
            $this->plugin_id     = $plugin_id;
            $this->plugin_file   = $plugin_file;
            $this->section_slug  = $section_slug;
            $this->settings_page = $settings_page;
        }

        public function register() {
            if ( $this->settings_page ) {
                add_filter( 'woocommerce_get_settings_' . $this->section_slug, array( $this, 'add_promo' ), 11, 1 );
            } else {
                add_filter( 'woocommerce_get_settings_products', array( $this, 'add_product_section_promo' ), 11, 2 );
            }

            add_action( 'admin_enqueue_scripts', array( $this, 'load_styles' ) );
        }

        public function add_product_section_promo( $settings, $current_section ) {
            // Check we're on the correct settings section
            if ( $this->section_slug !== $current_section ) {
                return $settings;
            }
            return $this->add_promo( $settings );
        }

        public function add_promo( $settings ) {
            if ( ( $promo_content = get_transient( 'OptimizeForm_plugin_promo_' . $this->plugin_id ) ) === false ) {
                $promo_response = wp_remote_get( 'https://optimizeform.com/wp-json/OptimizeForm/v2/pluginpromo/' . $this->plugin_id );

                if ( wp_remote_retrieve_response_code( $promo_response ) != 200 ) {
                    return $settings;
                }

                $promo_content = json_decode( wp_remote_retrieve_body( $promo_response ), true );

                set_transient( 'OptimizeForm_plugin_promo_' . $this->plugin_id, $promo_content, DAY_IN_SECONDS );
            }

            if ( empty( $promo_content ) || is_array( $promo_content ) ) {
                return $settings;
            }

            $settings[0]['class'] = $settings[0]['class'] . ' promo';

            $plugin_settings = array(
                array(
                    'id'    => 'OptimizeForm_plugin_promo',
                    'type'  => 'settings_start',
                    'class' => 'OptimizeForm-plugin-promo'
                )
            );

            $plugin_settings[] = array(
                'id'   => 'OptimizeForm_plugin_promo_content',
                'type' => 'plugin_promo',
                'content' => $promo_content
            );

            $plugin_settings[] = array(
                'id'   => 'OptimizeForm_plugin_promo',
                'type' => 'settings_end'
            );

            return array_merge( $settings, $plugin_settings );
        }

        public function load_styles() {
            wp_enqueue_style( 'OptimizeForm-promo', plugins_url( 'lib/assets/css/admin/plugin-promo.min.css', $this->plugin_file ) );
        }

    }

}