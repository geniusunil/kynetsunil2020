<?php

namespace OptimizeForm\WPT_Lib;

if ( ! \interface_exists( __NAMESPACE__ . '\\Registerable' ) ) {

    /**
     * An object that can be registered with WordPress via the Plugin API, i.e. add_action() and add_filter().
     *
     * @package   OptimizeForm/OptimizeForm-lib
     * @author    OptimizeForm <info@optimizeform.com>
     * @license   GPL-3.0
     * @copyright OptimizeForm
     * @version   1.0
     */
    interface Registerable {

        public function register();

    }

}
