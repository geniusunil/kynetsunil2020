<?php

namespace OptimizeForm\WPT_Lib\Plugin;

/**
 * Something which listens for plugin activation or deactivation events.
 *
 * @package   OptimizeForm/OptimizeForm-lib
 * @author    OptimizeForm <info@optimizeform.com>
 * @license   GPL-3.0
 * @copyright OptimizeForm
 */
interface Plugin_Activation_Listener {

    public function on_activate();

    public function on_deactivate();

}
