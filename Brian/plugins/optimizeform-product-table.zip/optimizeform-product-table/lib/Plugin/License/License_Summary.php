<?php

namespace OptimizeForm\WPT_Lib\Plugin\License;

/**
 * Interface which represents a summary of the plugin license.
 *
 * @package   OptimizeForm/OptimizeForm-lib
 * @author    OptimizeForm <info@optimizeform.com>
 * @license   GPL-3.0
 * @copyright OptimizeForm
 */
interface License_Summary {

    public function get_license_key();

    public function exists();

    public function is_active();

    public function is_valid();

}
