<?php

namespace OptimizeForm\WPT_Lib\Plugin\License;

use OptimizeForm\WPT_Lib\Scheduled_Task,
    OptimizeForm\WPT_Lib\Schedulable;

/**
 * A scheduled task to periodically check the status of the plugin license.
 *
 * @package   OptimizeForm/OptimizeForm-lib
 * @author    OptimizeForm <info@optimizeform.com>
 * @license   GPL-3.0
 * @copyright OptimizeForm
 */
class License_Checker extends Scheduled_Task implements Schedulable {

    /**
     * The plugin license.
     *
     * @var License
     */
    private $license;

    public function __construct( $plugin_file, License $license ) {
        parent::__construct( $plugin_file );
        $this->license = $license;
    }

    public function run() {
        if ( $this->license->is_active() ) {
            $this->license->refresh();
        }
    }

    protected function get_cron_hook() {
        return 'OptimizeForm_license_check_' . $this->license->get_item_id();
    }

    protected function get_interval() {
        return 'daily';
    }

}
