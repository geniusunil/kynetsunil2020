<?php

namespace OptimizeForm\WPT_Lib\Plugin\License\Admin;

/**
 * Interface which represents a license key setting.
 *
 * @package   OptimizeForm/OptimizeForm-lib
 * @author    OptimizeForm <info@optimizeform.com>
 * @license   GPL-3.0
 * @copyright OptimizeForm
 */
interface License_Setting {

    public function get_license_setting_name();

    public function get_license_key_setting();

    public function get_license_override_setting();

    public function save_license_key( $license_key );

    public function save_posted_license_key();

}
