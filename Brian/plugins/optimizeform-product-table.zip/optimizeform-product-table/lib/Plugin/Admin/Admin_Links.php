<?php

namespace OptimizeForm\WPT_Lib\Plugin\Admin;

use OptimizeForm\WPT_Lib\Registerable,
    OptimizeForm\WPT_Lib\Service,
    OptimizeForm\WPT_Lib\Plugin\Plugin;

/**
 * Core admin functions for our plugins (e.g. adding the settings link).
 *
 * @package   OptimizeForm/OptimizeForm-lib
 * @author    OptimizeForm <info@optimizeform.com>
 * @license   GPL-3.0
 * @copyright OptimizeForm
 */
class Admin_Links implements Registerable, Service {

    /**
     * @var Plugin The core plugin data (ID, version, etc).
     */
    protected $plugin;

    public function __construct( Plugin $plugin ) {
        $this->plugin = $plugin;
    }

    public function register() {
        // Add settings link from Plugins page.
        \add_filter( 'plugin_action_links_' . $this->plugin->get_basename(), array( $this, 'add_settings_link' ) );

        // Add documentation link to meta info on Plugins page.
        \add_filter( 'plugin_row_meta', array( $this, 'add_documentation_link' ), 10, 2 );
    }

    public function add_settings_link( $links ) {
        if ( ! ( $settings_url = $this->plugin->get_settings_page_url() ) ) {
            return $links;
        }

        // Don't add link if it's a WooCommerce plugin but WooCommerce is not activated.
        if ( $this->plugin->is_woocommerce() && ! \class_exists( '\WooCommerce' ) ) {
            return $links;
        }

        \array_unshift( $links, \sprintf( '<a href="%1$s">%2$s</a>', \esc_url( $settings_url ), __( 'Settings', 'woocommerce-product-table' ) ) );
        return $links;
    }

    public function add_documentation_link( $links, $file ) {
        if ( $file !== $this->plugin->get_basename() ) {
            return $links;
        }

        // Bail if there's no documentation URL.
        if ( ! ( $documentation_url = $this->plugin->get_documentation_url() ) ) {
            return $links;
        }

        $row_meta = array(
            'docs' => \sprintf(
                '<a href="%1$s" aria-label="%2$s" target="_blank">%3$s</a>',
                \esc_url( $documentation_url ),
                \esc_attr( \sprintf( __( 'View %s documentation', 'woocommerce-product-table' ), $this->plugin->get_name() ) ),
                \esc_html__( 'Docs', 'woocommerce-product-table' )
            )
        );

        return \array_merge( $links, $row_meta );
    }

}
