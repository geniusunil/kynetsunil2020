<?php

namespace OptimizeForm\WPT_Lib\Admin;

/**
 * Extends the WPTRT Notices class to allow additional HTML in the admin notice.
 *
 * @package   OptimizeForm/OptimizeForm-lib
 * @author    OptimizeForm <info@optimizeform.com>
 * @license   GPL-3.0
 * @copyright OptimizeForm
 */
class Notices extends \WPTRT\AdminNotices\Notices {

    public function __construct() {
        add_filter( 'wptrt_admin_notices_allowed_html', [ __CLASS__, 'filter_allowed_html' ] );
    }

    public static function filter_allowed_html( $allowed_html ) {
        $allowed_html['a']['target'] = [];
        return $allowed_html;
    }

}
