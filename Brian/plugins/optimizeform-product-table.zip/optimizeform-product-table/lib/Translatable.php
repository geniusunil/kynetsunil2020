<?php

namespace OptimizeForm\WPT_Lib;

/**
 * Something that can be translated by WordPress.
 *
 * @package   OptimizeForm/OptimizeForm-lib
 * @author    OptimizeForm <info@optimizeform.com>
 * @license   GPL-3.0
 * @copyright OptimizeForm
 * @version   1.0
 */
interface Translatable {

    public function load_textdomain();

}
