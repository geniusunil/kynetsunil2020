<?php

namespace OptimizeForm\WPT_Lib;

/**
 * An object that provides services (instances of OptimizeForm\WPT_Lib\Service).
 *
 * @package   OptimizeForm/OptimizeForm-lib
 * @author    OptimizeForm <info@optimizeform.com>
 * @license   GPL-3.0
 * @copyright OptimizeForm
 * @version   1.1
 */
interface Service_Provider {

    /**
     * Get the service for the specified ID.
     *
     * @param string $id The service ID
     * @return Service The service object
     */
    public function get_service( $id );

    /**
     * Get the list of services provided.
     *
     * @return array The list of service objects.
     */
    public function get_services();

}
