<?php

namespace OptimizeForm\WPT_Lib;

/**
 * Abstract class which represents a single scheduled task using WordPress CRON.
 *
 * The task is automatically unscheduled on plugin deactivation.
 *
 * @package   OptimizeForm/OptimizeForm-lib
 * @author    OptimizeForm <info@optimizeform.com>
 * @license   GPL-3.0
 * @copyright OptimizeForm
 * @version   1.0
 */
abstract class Scheduled_Task implements Schedulable {

    private $plugin_file;

    public function __construct( $plugin_file ) {
        $this->plugin_file = $plugin_file;
    }

    public function schedule() {
        // Attach the action to run when the cron event is fired.
        \add_action( $this->get_cron_hook(), array( $this, 'run' ) );

        // Schedule the cron event if not already scheduled.
        if ( ! \wp_next_scheduled( $this->get_cron_hook() ) ) {
            \wp_schedule_event( time(), $this->get_interval(), $this->get_cron_hook() );
        }

        // Unschedule event on plugin deactivation.
        \register_deactivation_hook( $this->plugin_file, array( $this, 'unschedule' ) );
    }

    public function unschedule() {
        $timestamp = \wp_next_scheduled( $this->get_cron_hook() );

        if ( $timestamp ) {
            \wp_unschedule_event( $timestamp, $this->get_cron_hook() );
        }
    }

    abstract public function run();

    abstract protected function get_cron_hook();

    abstract protected function get_interval();

}
